﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int I = 1;
            while (I <= 10)
            {
                Console.WriteLine(I);
                I = I + 1;
                

                
            }
            Console.ReadKey();
        }
    }
}

